import org.com.model.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class EmployeeMain {

	public static void main(String[] args) {
			
		Configuration cfg=new Configuration();
		cfg.configure();
		
		SessionFactory sf=cfg.buildSessionFactory();
		
		Session session=sf.openSession();
		
		Transaction transaction=session.beginTransaction();
		
		Employee emp1=new Employee();
		emp1.setId(1003);
		emp1.setName("sohan kumar");
		emp1.setSalary(20000);
		
		transaction.begin();
		
		session.save(emp1);
		
		transaction.commit();
		
		System.out.println("Record added");
		
		
	}
}
